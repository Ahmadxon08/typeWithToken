import PageRoutes from "./router";

const App = () => {
  return (
    <div>
      <PageRoutes />
    </div>
  );
};

export default App;
